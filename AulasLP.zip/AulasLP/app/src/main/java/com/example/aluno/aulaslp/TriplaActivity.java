package com.example.aluno.aulaslp;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.aluno.aulaslp.R;

/**
 * Created by Aluno on 28/08/2018.
 */

public class TriplaActivity extends AppCompatActivity {
   // Registro pri, seg, ult, aux;
    EditText edNome, edProfissao, edIdade;
    int numReg,pos;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        carregarTela3();
    }

    public void carregarTela3(){
        setContentView(R.layout.activity_tripla_3);
        Button btnCadastrarPessoas = (Button) findViewById(R.id.btnCadastrarPessoas);
        btnCadastrarPessoas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                carregarTela2();
            }
        });
        Button btnListarPessoas = (Button) findViewById(R.id.btnListarPessoas);
        btnListarPessoas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                carregarTela1();
            }
        });
    }
    public void carregarTela2(){
        setContentView(R.layout.activity_tripla_2);
        Button btnCadastrar = (Button) findViewById(R.id.btnCadastrar);
        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edNome = (EditText) findViewById(R.id.edNome);
                edProfissao = (EditText) findViewById(R.id.edProfissao);
                edIdade = (EditText) findViewById(R.id.edIdade);

                carregarTela3();

            }
        });
        Button btnCancelar = (Button) findViewById(R.id.btnCancelar);
        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                carregarTela3();
            }
        });
    }
    public void carregarTela1(){
        setContentView(R.layout.activity_tripla_1);
        Button btnMenu = (Button) findViewById(R.id.btnMenu);
        btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                carregarTela3();
            }
        });
    }
}
