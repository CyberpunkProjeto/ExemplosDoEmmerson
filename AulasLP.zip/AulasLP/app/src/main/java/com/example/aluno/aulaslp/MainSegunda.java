package com.example.aluno.aulaslp;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

/**
 * Created by Aluno on 21/08/2018.
 */

public class MainSegunda extends AppCompatActivity{


    private static final String[] percentual = {"De 40%", "De 45%", "De 50%"};
    ArrayAdapter<String> aPercentual;
    Spinner spnSal;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda);

        Button btnMostrar = (Button) findViewById(R.id.btnMostrar);

        aPercentual = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, percentual);

        spnSal = (Spinner) findViewById(R.id.spnOpcoes);
        spnSal.setAdapter(aPercentual);

        btnMostrar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View arg0) {
                double salario = 0, novo_sal = 0;

                EditText txtSalario = (EditText) findViewById(R.id.txtSalario);

                salario = Double.parseDouble(txtSalario.getText().toString());

                switch (spnSal.getSelectedItemPosition()){
                    case 0: novo_sal = salario + (salario*0.4); break;
                    case 1: novo_sal = salario + (salario*0.45); break;
                    case 2: novo_sal = salario + (salario*0.50); break;
                }
                AlertDialog.Builder dialogo = new
                        AlertDialog.Builder(MainSegunda.this);
                dialogo.setTitle("Novo salário.");
                dialogo.setMessage("Seu novo salário é: R$"+ String.valueOf(novo_sal));
                dialogo.setNeutralButton("Ok", null);
                dialogo.show();
            }
        });
    }
}
