package com.example.aluno.aulaslp;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

/**
 * Created by Aluno on 27/08/2018.
 */

public class QuartaActivity extends AppCompatActivity{
    Button btn1;
    Button btn2;
    Button btn3;
    Button btn4;
    Button btn5;
    Button btn6;
    Button btn7;
    Button btn8;
    Button btn9;
    Button btn0;
    Button btnSomar;
    Button btnDividir;
    Button btnSubtrair;
    Button btnMultiplicar;
    Button btnResultado;
    EditText txtNumeros;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quarta);

        btn0 = (Button) findViewById(R.id.btn0);
        btn1 = (Button) findViewById(R.id.btn1);
        btn2 = (Button) findViewById(R.id.btn2);
        btn3 = (Button) findViewById(R.id.btn3);
        btn4 = (Button) findViewById(R.id.btn4);
        btn5 = (Button) findViewById(R.id.btn5);
        btn6 = (Button) findViewById(R.id.btn6);
        btn7 = (Button) findViewById(R.id.btn7);
        btn8 = (Button) findViewById(R.id.btn8);
        btn9 = (Button) findViewById(R.id.btn9);
        btnSomar = (Button) findViewById(R.id.btnSomar);
        btnDividir = (Button) findViewById(R.id.btnDividir);
        btnSubtrair = (Button) findViewById(R.id.btnSubtrair);
        btnMultiplicar = (Button) findViewById(R.id.btnMultiplicar);
        btnResultado = (Button) findViewById(R.id.btnResultado);
        txtNumeros = (EditText) findViewById(R.id.txtNumeros);
    }

    public void pressionar(View v){
        int n1, n2;

        char op;

        boolean vN1 = false, vN2 = false, vOP = false;

        if(btn0.isPressed() && vOP == false){
            txtNumeros.setText((txtNumeros.getText().toString()) + "0");
        }
        else if(btn0.isPressed() && vOP == true){
            n1 = Integer.parseInt(txtNumeros.getText().toString());
            txtNumeros.setText("");
        }
        else if(btn1.isPressed()){
            txtNumeros.setText(btn1.getText().toString());
        }
        else if(btn2.isPressed()){
            txtNumeros.setText(btn2.getText().toString());
        }
        else if(btn3.isPressed()){
            txtNumeros.setText(btn3.getText().toString());
        }
        else if(btn4.isPressed()){
            txtNumeros.setText(btn4.getText().toString());
        }
        else if(btn5.isPressed()){
            txtNumeros.setText(btn5.getText().toString());
        }
        else if(btn6.isPressed()){
            txtNumeros.setText(btn6.getText().toString());
        }
        else if(btn7.isPressed()){
            txtNumeros.setText(btn7.getText().toString());
        }
        else if(btn8.isPressed()){
            txtNumeros.setText(btn8.getText().toString());
        }
        else if(btn9.isPressed()){
            txtNumeros.setText(btn9.getText().toString());
        }
        else if(btnSomar.isPressed()){
            vOP = true;
            txtNumeros.setText("");
        }
    }
}
