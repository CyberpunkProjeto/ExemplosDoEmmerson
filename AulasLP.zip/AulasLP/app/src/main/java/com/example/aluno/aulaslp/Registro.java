package com.example.aluno.aulaslp;

/**
 * Created by Aluno on 28/08/2018.
 */

public class Registro {
}
