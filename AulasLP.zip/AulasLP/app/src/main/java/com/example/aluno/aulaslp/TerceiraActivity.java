package com.example.aluno.aulaslp;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class TerceiraActivity extends AppCompatActivity {
    public ListView lista;
    static final String[] contatos = new String[]{"Alline", "Lucas", "Gabriela", "Rafael", "Rodrigo"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terceira);

        ArrayAdapter<String> adapter = new
                ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, contatos);
        lista = (ListView) findViewById(R.id.lstContatos);
        lista.setAdapter(adapter);
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView arg0, View arg1, int arg2, long arg3) {
                if(lista.getItemAtPosition(arg2) != null){
                    AlertDialog.Builder dialogo = new AlertDialog.Builder(TerceiraActivity.this);
                    dialogo.setTitle("Contato selecionado.");
                    dialogo.setMessage(lista.getSelectedItem().toString());
                    dialogo.setNeutralButton("Ok", null);
                    dialogo.show();
                }
            }
        });

    }

}
