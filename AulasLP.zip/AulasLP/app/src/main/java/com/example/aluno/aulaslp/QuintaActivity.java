package com.example.aluno.aulaslp;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.example.aluno.aulaslp.R;

/**
 * Created by Aluno on 28/08/2018.
 */

public class QuintaActivity extends AppCompatActivity {
    Button btnTelaPrincipal;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        carregarTelaPrincipal();

    }
    public void carregarTelaPrincipal(){
        setContentView(R.layout.activity_quinta);
        Button btnTela2 = (Button) findViewById(R.id.btnTela2);
        btnTela2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                carregarTela2();
            }
        });
    }
    public void carregarTela2(){
        setContentView(R.layout.tela2);
        btnTelaPrincipal = (Button) findViewById(R.id.btnTelaPrincipal);
        btnTelaPrincipal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                carregarTelaPrincipal();
            }
        });
    }
}
